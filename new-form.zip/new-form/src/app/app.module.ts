import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { NewcomponemtComponent } from './newcomponemt/newcomponemt.component';
import { from } from 'rxjs';
import {squart} from './squart';
import {MyServiceService} from './my-service.service';
import{HttpClientModule} from '@angular/common/http';
import{FormsModule} from '@angular/forms';
import{ReactiveFormsModule} from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    NewcomponemtComponent,
    squart
  ],
  imports: [
    RouterModule.forRoot([
      {
        path:'new-component',
        component:NewcomponemtComponent
      }
    ]),
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
