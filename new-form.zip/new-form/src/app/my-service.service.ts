import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {

  constructor() { }
  showDate()
  {
    let date= new Date();
    return date;
  }
}
