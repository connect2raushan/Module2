import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewcomponemtComponent } from './newcomponemt.component';

describe('NewcomponemtComponent', () => {
  let component: NewcomponemtComponent;
  let fixture: ComponentFixture<NewcomponemtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewcomponemtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewcomponemtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
