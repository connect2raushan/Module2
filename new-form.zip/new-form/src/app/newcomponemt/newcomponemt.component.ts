import { Component, OnInit } from '@angular/core';
import {MyServiceService} from './../my-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-newcomponemt',
  templateUrl: './newcomponemt.component.html',
  styleUrls: ['./newcomponemt.component.css']
})
export class NewcomponemtComponent implements OnInit {
  name:string='raushan';
  salary:number=400;
  newdate;

  constructor(private myservice:MyServiceService) { }

  ngOnInit() {
    this.newdate=this.myservice.showDate();
  }

}
