import { Component } from '@angular/core';
import {MyServiceService} from './my-service.service';
import{HttpClient} from '@angular/common/http';
import { from, Subscriber } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'new-form';
  num:number=25;
  newdate;
  httpdata;
  searchid=6;
  constructor(private myservice:MyServiceService, private http:HttpClient)
  {}
  ngOnInit()
  {
    this.newdate=this.myservice.showDate();
    this.http.get("assets/booklist.json").subscribe((data)=>this.display(data))
    

  }
  
display(data)
{
this.httpdata=data;
}
onSubmit(data)
{
  alert(data.uname+": "+data.password);
}
}
