import {Pipe, PipeTransform} from '@angular/core';
import { pipe } from 'rxjs';
@Pipe({
    name:'sqrt'
})
export class squart implements PipeTransform{
    transform(val : number) : number {
        return Math.sqrt(val);
    }
}