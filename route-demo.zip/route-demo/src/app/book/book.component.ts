import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { IBook } from './book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  book:IBook[];
  
  isUpdate:boolean=false;
  id:number;
  title:string;
  year:number;
  author:string;


  constructor(private service:BookService) { }

  ngOnInit() {
    this.service.getBooks().subscribe(data=>this.book=data);
  }
  update(book:IBook)
  {
    this.id=book.id;
    this.author=book.author;
    this.title=book.title;
    this.year=book.year;
    this.isUpdate=true;
  }
  delete(book:IBook)
  {
    let arr= this.book.filter(p => p.id != book.id);
    this.book=arr;
  }
  updateDetails()
  {
    let arr=this.book.filter(p=>p.id!=this.id);
    arr.push({id:this.id, title:this.title, year:this.year, author:this.author});
    this.book=arr;
    this.isUpdate=false;
    
  }
  

}
