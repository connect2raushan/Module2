export interface IEmployee
{
    eid:number;
    ename:string;
    esalary:number;
}