import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import { Route,RouterModule } from '@angular/router';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { BookComponent } from './book/book.component';
import {HttpClientModule} from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { BookformComponent } from './bookform/bookform.component';

const routes:Route []=[
  {
    path:'bookform',
    component:BookformComponent
  },
  {path:'user',
  component:UserComponent
},
  {
    path:'book',
    component:BookComponent
  },
  {
    path:'empdetails/:id',
    component:EmployeedetailsComponent
  },
  {
  path:'emp',
  component:EmployeeComponent
},
{
  path:'dept',
  component:DepartmentComponent
},
{path:'',
redirectTo:'emp',
pathMatch:'full'
},
{
  path:"**",
  component:DepartmentComponent
}];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    DepartmentComponent,
    EmployeedetailsComponent,
    BookComponent,
    UserComponent,
    BookformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
