package com.cg.ac.bean;

public class Customer {
	private String name;
	private String panNo;
	private String aadharNo;
	private String accountType;
	private double balance;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String panNo, String aadharNo, String accountType, double balance) {
		super();
		this.name = name;
		this.panNo = panNo;
		this.aadharNo = aadharNo;
		this.accountType = accountType;
		this.balance = balance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", panNo=" + panNo + ", aadharNo=" + aadharNo + ", accountType=" + accountType
				+ ", balance=" + balance + "]";
	}
	

}
